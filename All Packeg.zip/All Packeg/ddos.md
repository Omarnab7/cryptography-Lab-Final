# Multithreaded TCP Socket Message Sender

## Overview

This Python script implements a multithreaded TCP client that connects to a specified IP address and port, sends messages, and handles responses. It is designed primarily for testing or simulation purposes, where multiple threads simulate repeated client connections to a server.

> ⚠️ **Warning**: This script performs multiple automated TCP connections and sends data. It should **only be used with permission** on systems you own or are authorized to test. Unauthorized usage may violate legal and ethical guidelines.

---

## Features

- Multithreaded TCP connections
- Customizable message payload
- Configurable number of threads and message repetitions per thread
- Output logging for each thread's activity

---

## Usage

You can invoke the main functionality using the `run_attack()` function.

### Function Signature

```python
run_attack(ip: str, port: int, msg: str, num_threads: int, num_runs: int)
```

### Parameters

| Parameter     | Type | Description                                    |
| ------------- | ---- | ---------------------------------------------- |
| `ip`          | str  | The target server's IP address.                |
| `port`        | int  | The target server's port.                      |
| `msg`         | str  | The message payload each client sends.         |
| `num_threads` | int  | Number of concurrent threads (clients).        |
| `num_runs`    | int  | Number of times each thread sends the message. |

---

## How It Works

1. The `run_attack()` function creates multiple `_AttackThread` instances.
2. Each thread calls the `_attack()` function:
   - Establishes a TCP connection.
   - Sends a formatted message containing the thread and run number.
   - Waits to receive a response from the server.
   - Closes the socket gracefully.
3. The program logs each step to `stderr`.

---

## Example

```python
if __name__ == "__main__":
    run_attack(ip="127.0.0.1", port=8080, msg="Hello Server!", num_threads=5, num_runs=10)
```

This command:

- Starts 5 threads
- Each thread connects to `127.0.0.1:8080` and sends 10 messages
- Logs all communication to `stderr`

---

## Code Structure

- `_attack`: Handles socket connection, message sending, and response reading.
- `_AttackThread`: Custom thread class that wraps `_attack`.
- `run_attack`: Entry point to start all threads and coordinate their execution.

---

## Notes

- This is intended for development, testing, or educational purposes only.
- Socket errors are caught and printed to avoid crashing threads.
- The code uses basic `socket` and `threading` modules (no external dependencies).

---

## License

Ruppin Academic Center Students usage only. Use at your own risk.
