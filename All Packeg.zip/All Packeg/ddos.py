import socket
import sys
import threading

# Internal attack logic
def _attack(ip, port, msg, thread_id, num_runs):
    for run in range(num_runs):
        try:
            #connecting to server socket
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            server_address = (ip, port)
            print(f"[Thread {thread_id}] Connecting to {ip}:{port}\n", file=sys.stderr)
            sock.connect(server_address)

            #message handler
            message = f"Thread-{thread_id}, Run-{run + 1}: {msg}"
            encoded_msg = message.encode()
            print(f"[Thread {thread_id}] Sending: {message}\n", file=sys.stderr)
            sock.sendall(encoded_msg)

            amount_received = 0
            amount_expected = len(encoded_msg)

            while amount_received < amount_expected:
                data = sock.recv(16)
                if not data:
                    break
                amount_received += len(data)
                print(f"[Thread {thread_id}] Received: {data.decode()}\n", file=sys.stderr)

        except Exception as e:
            print(f"[Thread {thread_id}] Error: {e}\n", file=sys.stderr)
        finally:
            sock.close()
            print(f"[Thread {thread_id}] Socket closed\n", file=sys.stderr)

# Thread class
class _AttackThread(threading.Thread):
    def __init__(self, thread_id, ip, port, msg, num_runs):
        threading.Thread.__init__(self)
        self.thread_id = thread_id
        self.ip = ip
        self.port = port
        self.msg = msg
        self.num_runs = num_runs

    def run(self):
        print(f"Starting Thread-{self.thread_id}\n")
        _attack(self.ip, self.port, self.msg, self.thread_id, self.num_runs)
        print(f"Exiting Thread-{self.thread_id}\n")

#Main entry point you can call
def run_attack(ip: str, port: int, msg: str, num_threads: int, num_runs: int):
    threads = []
    for i in range(num_threads):
        thread = _AttackThread(i + 1, ip, port, msg, num_runs)
        thread.start()
        threads.append(thread)

    for thread in threads:
        thread.join()

    print("\n***All threads finished. Exiting attack.***\n")

