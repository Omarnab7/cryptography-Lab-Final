from itertools import cycle

def encrypt_vigenere(plaintext, key):
    """
    Encrypt text using Vigenère cipher.
    
    Args:
        plaintext (str): Text to encrypt
        key (str): Encryption key
    
    Returns:
        str: Encrypted text
    """
    encrypted = []
    key_cycle = cycle(key.upper())
    
    for char in plaintext:
        if char.isalpha():
            key_char = next(key_cycle)
            shift = ord(key_char) - ord('A')
            
            if char.isupper():
                encrypted_char = chr((ord(char) - ord('A') + shift) % 26 + ord('A'))
            else:
                encrypted_char = chr((ord(char) - ord('a') + shift) % 26 + ord('a'))
            
            encrypted.append(encrypted_char)
        else:
            encrypted.append(char)
    
    return ''.join(encrypted)

def decrypt_vigenere(ciphertext, key):
    """
    Decrypt text using Vigenère cipher.
    
    Args:
        ciphertext (str): Text to decrypt
        key (str): Decryption key
    
    Returns:
        str: Decrypted text
    """
    decrypted = []
    key_cycle = cycle(key.upper())
    
    for char in ciphertext:
        if char.isalpha():
            key_char = next(key_cycle)
            shift = ord(key_char) - ord('A')
            
            if char.isupper():
                decrypted_char = chr((ord(char) - ord('A') - shift) % 26 + ord('A'))
            else:
                decrypted_char = chr((ord(char) - ord('a') - shift) % 26 + ord('a'))
            
            decrypted.append(decrypted_char)
        else:
            decrypted.append(char)
    
    return ''.join(decrypted)