import tkinter as tk
from tkinter import ttk, messagebox
from tkinter import filedialog
#from point2 import highlight_word_in_url_with_parsing as scrape_url # type: ignore
#from point3 import FernetEncryptor, hash_sha256 # type: ignore
from SHA_256_fernet import FernetEncryptor
from SHA_256_fernet import hash_sha256

### --- FUNCTION MAPPINGS --- ###
def encrypt_fernet(data, key):
    return FernetEncryptor().encrypt(data, str)
    # return f"Encrypted(Fernet): {data} with {key}"

# def hash_sha256(data):
#     return f"SHA256: {data}"

def MSSP_Encrypt(data, key):
    return f"MSSP: {data} with {key}"

# def scrape_url(url, target):
#     print(f"Scraping {url} for {target}")

### --- GUI MODULES --- ###

class CustomApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Enctyption Tools")
        self.root.geometry("800x600")

        # Top level containers
        self.create_logo("Omar Alnabilsi & Neev Penkar\nCustom Logo")
        self.create_nav_buttons()
        self.main_frame = tk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True)

    def create_logo(self, text):
        logo = tk.Label(self.root, text=text, font=("Arial", 20), fg="blue", justify="center")
        logo.pack(pady=5)

    def create_nav_buttons(self):
        nav_frame = tk.Frame(self.root)
        nav_frame.pack(pady=5)

        buttons = {
            "Hash": self.render_hash_ui,
            "Encrypt": self.render_encrypt_ui,
            "Fake": self.render_fake_ui,
            "URL Scrape": self.render_scrape_ui,
            "DDOS" : self.render_ddos_ui,
            "Exit": self.root.quit
        }

        for label, command in buttons.items():
            b = tk.Button(nav_frame, text=label, command=command)
            b.pack(side=tk.LEFT, padx=5)

    def clear_main(self):
        for widget in self.main_frame.winfo_children():
            widget.destroy()
    
    def attach_file(self):
        file_path = filedialog.askopenfilename()
        if file_path:
            self.file_label.config(text=file_path)
            try:
                with open(file_path, 'rb') as f:
                    self.file_content = f.read()
            except Exception as e:
                messagebox.showerror("File Error", str(e))
                self.file_content = b""   

    #### WORKING WELL ####
    def render_hash_ui(self):
        self.clear_main()

        # Data entry
        tk.Label(self.main_frame, text="Data").pack()
        data_entry = tk.Text(self.main_frame, height=3)
        data_entry.pack()

        # Attach file
        attach_button = tk.Button(self.main_frame, text="Attach Key", command=self.attach_file)
        attach_button.pack()

        self.file_label = tk.Label(self.main_frame, text="No key selected")
        self.file_label.pack()

        # Output area
        tk.Label(self.main_frame, text="Output").pack()
        output = tk.Text(self.main_frame, height=3, state="disabled")
        output.pack()

        # Algorithm selector
        algo = tk.StringVar()
        algo.set("Fernet")
        algo_menu = ttk.Combobox(self.main_frame, textvariable=algo, values=["Fernet", "SHA256"])
        algo_menu.pack(pady=5)

        # Go button logic
        def on_go():
            try:
                data = data_entry.get("1.0", tk.END).strip().encode()

                if algo.get() == "Fernet":
                    if not self.file_content:
                        raise ValueError("You must attach a key file for Fernet encryption.")
                    result = encrypt_fernet(data, self.file_content)
                else:
                    result = hash_sha256(data, str)

                output.config(state="normal")
                output.delete("1.0", tk.END)
                output.insert(tk.END, result)
                output.config(state="disabled")
            except Exception as e:
                messagebox.showerror("Error", str(e))

        tk.Button(self.main_frame, text="Go", command=on_go).pack(pady=5)
    #### WORKING WELL ####

    def render_ddos_ui(self):
        self.clear_main()

        tk.Label(self.main_frame, text="Target IP").pack()
        target_entry = tk.Text(self.main_frame, height=1, width=14)
        target_entry.pack()

        tk.Label(self.main_frame, text="Port number").pack()
        port_entry = tk.Text(self.main_frame, height=1, width=14)
        port_entry.pack()

        tk.Label(self.main_frame, text="Message to send").pack()
        msg_entry = tk.Text(self.main_frame, height=4, width=14)
        msg_entry.pack()

        tk.Label(self.main_frame, text="Number of threads").pack()
        threads_entry = tk.Text(self.main_frame, height=1, width=14)
        threads_entry.pack()

        tk.Label(self.main_frame, text="Number of runs").pack()
        runs_entry = tk.Text(self.main_frame, height=1, width=14)
        runs_entry.pack()

        def on_go():
            try:
                print("HELLO FROM DDOS")
            except Exception as e:
                messagebox.showerror("Error", str(e))

        tk.Button(self.main_frame, text="Go", command=on_go).pack(pady=5)
   
    #### WORKING WELL ####
    def render_encrypt_ui(self):
        self.clear_main()

        import tkinter as tk
        from tkinter import messagebox
        from MSSP import mssp_decode

        tk.Label(self.main_frame, text="Data").pack()
        data_entry = tk.Text(self.main_frame, height=3)
        data_entry.pack(pady=5)

        # Frame for keys
        keys_frame = tk.Frame(self.main_frame)
        keys_frame.pack(pady=5)

        # Keyn
        frame1 = tk.Frame(keys_frame)
        frame1.pack(side='left', padx=10)
        tk.Label(frame1, text="Keyn").pack()
        key1_entry = tk.Text(frame1, height=2, width=20)
        key1_entry.pack()

        # Keyd
        frame2 = tk.Frame(keys_frame)
        frame2.pack(side='left', padx=10)
        tk.Label(frame2, text="Keyd").pack()
        key2_entry = tk.Text(frame2, height=2, width=20)
        key2_entry.pack()

        # Output
        tk.Label(self.main_frame, text="Output").pack()
        output = tk.Text(self.main_frame, height=3, state="disabled")
        output.pack(pady=5)

        def on_go():
            try:
                UsersNum = data_entry.get("1.0", tk.END).strip()
                keyn_raw = key1_entry.get("1.0", tk.END).strip()
                keyd_raw = key2_entry.get("1.0", tk.END).strip()

                # Validate UsersNum is digits only
                if not UsersNum.isdigit():
                    raise ValueError("Data must contain only digits.")

                # Convert and validate keys
                if not (keyn_raw.isdigit() and keyd_raw.isdigit()):
                    raise ValueError("Keyn and Keyd must be valid integers.")

                keyn = int(keyn_raw)
                keyd = int(keyd_raw)

                result = mssp_decode(UsersNum, keyn, keyd)

                output.config(state="normal")
                output.delete("1.0", tk.END)
                output.insert(tk.END, str(result))  # display int or str
                output.config(state="disabled")
            except Exception as e:
                messagebox.showerror("Error", str(e))

        tk.Button(self.main_frame, text="Go", command=on_go).pack(pady=5)
    #### WORKING WELL ####

    #### WORKING WELL ####
    def render_scrape_ui(self):
        self.clear_main()

        tk.Label(self.main_frame, text="URL").pack()
        url_entry = tk.Entry(self.main_frame, width=60)
        url_entry.pack()

        tk.Label(self.main_frame, text="Target").pack()
        target_entry = tk.Entry(self.main_frame, width=60)
        target_entry.pack()

        from request_URL import highlight_word_in_url_with_parsing, show_html_with_highlight

        def on_go():
            try:
                url = url_entry.get().strip()
                target = target_entry.get().strip()
                #highlight_word_in_url_with_parsing(f"{url}", f"{target}")
                show_html_with_highlight(f"{url}", f"{target}")
                messagebox.showinfo("Info", f"Scraping initiated for {target}")
            except Exception as e:
                messagebox.showerror("Error", str(e))

        tk.Button(self.main_frame, text="Go", command=on_go).pack(pady=5)
    #### WORKING WELL ####
    
    def render_fake_ui(self):
        self.clear_main()
        tk.Label(self.main_frame, text="Fake - Under Construction").pack(pady=20)

        # Algorithm selector
        algo = tk.StringVar()
        algo.set("English")
        algo_menu = ttk.Combobox(self.main_frame, textvariable=algo, values=["English", "Hebrew", "Arabic", "Japanese", "Italian"])
        algo_menu.pack(pady=5)
        
        tk.Label(self.main_frame, text="Data").pack()
        data_entry = tk.Text(self.main_frame, height=3)
        data_entry.pack()


        def on_go():
            try:
                data = data_entry.get("1.0", tk.END).strip().encode()

                if algo.get() == "English":
                    if not self.file_content:
                        raise ValueError("You must attach a key file for Fernet encryption.")
                    result = encrypt_fernet(data, self.file_content)
                else:
                    result = hash_sha256(data, str)

                output.config(state="normal")
                output.delete("1.0", tk.END)
                output.insert(tk.END, result)
                output.config(state="disabled")
            except Exception as e:
                messagebox.showerror("Error", str(e))


if __name__ == "__main__":
    root = tk.Tk()
    app = CustomApp(root)
    root.mainloop()
